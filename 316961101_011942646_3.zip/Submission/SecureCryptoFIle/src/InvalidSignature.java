public class InvalidSignature extends Exception {
    public InvalidSignature(String message) {
        super(message);
    }
}
